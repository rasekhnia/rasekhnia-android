# Rasekhnia Android

Android WebView client for https://rasekhnia.ir, version 1.2.0.

## Build without Android Studio

Open **Actions > Build Android APK > Run workflow**. After the workflow succeeds, download `rasekhnia-android-debug-apk` from the workflow run's **Artifacts** section and extract `app-debug.apk`.

This is a debug-signed testing APK, not a Play Store release. If the old APK was signed with a different certificate, uninstall it first (after backing up local app data). Test login, payments, file uploads/downloads, external links, and device compatibility. No successful device test is claimed.
